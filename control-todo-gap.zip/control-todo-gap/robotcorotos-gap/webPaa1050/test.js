var test = "735287Por favor introduce este código en Corotos para completar la verificación de la cuenta."

console.log(test[-1+test.indexOf("Por")]+test[-2+test.indexOf("Por")]+test[-3+test.indexOf("Por")]+test[-4+test.indexOf("Por")]+test[-5+test.indexOf("Por")]+test[-6+test.indexOf("Por")])
